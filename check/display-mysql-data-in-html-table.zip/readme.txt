1. Dump sales.sql to database using phpMyAdmin
2. Run displaying_data.php